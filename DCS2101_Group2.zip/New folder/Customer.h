#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string>
using namespace std;

class Customer{
	
public:
	//Constructor
	Customer();
	Customer(string a, string b,  string c, int d);
	
	//Setters
	void setCustomerId(string);
	void setName(string);
	void setAddress(string);
	void setPhoneNum(int);

	
	//Getters
	string getCustomerId();
	string getName();
	string getAddress();
	int getPhoneNum();

	
	
	
private:
	//Attributes
	string customerId;    //Customer ID attribute
	string name;          //Customer name attribute
	string address;       //Customer address attribute
	int phoneNum;         //Customer contact number attribute
	
	
};
#endif
