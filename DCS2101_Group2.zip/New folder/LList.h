#ifndef LLIST_H
#define LLIST_H
#include "Cake.h"

//Node attributes
struct node{
	Cake item;
	node* next;
};

class LList {
	private:
		node* head;
		node* curr;
		node* temp;
		node* tail;
		int numOfItem;
		double total;
		
	public:
		LList();
		bool isEmpty();
		int size();
		bool insertNode(int position, Cake data);
		bool deleteNode(int position);
		bool displayAll();
		bool deleteAll();
		double getTotal ();
		
};

#endif
