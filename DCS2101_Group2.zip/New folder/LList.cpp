#include "Customer.h"
#include "Cake.h"
#include "LList.h"
#include <iostream>
#include <iomanip>

using namespace std;

LList::LList() {
	head = NULL;
	curr = NULL;
	temp = NULL;
	tail = NULL;
	numOfItem = 0;
}

	
bool LList::isEmpty() {
	if (numOfItem == 0) 
		return true;
	else
    	return false;			
}


int LList::size(){
	return numOfItem;
}


bool LList::insertNode(int position, Cake info){
	
	//Validate position
	if (position > numOfItem + 1 || position < 1){
		return false;
	}
	
	//Create new node
	node *newNode = new node;
	newNode->item.setOrder(info.getCakeCode(), info.getFlavour(), info.getWeight (), info.getPrice(), info.getQty());
	newNode->next = NULL;
	
	node *curr = head;
	int temp;
	while (curr != NULL) {
		if (newNode -> item.getCakeCode() == curr->item.getCakeCode()){
			temp = curr->item.getQty();
			temp = temp + newNode-> item.getQty();
			curr->item.setQty(temp);
			return true;
		}
		
		curr = curr->next;
	}
	
	//Insert elements as head			
	if (position == 1){
		newNode->next = head;
		head = newNode;	
		if (tail == NULL)		
		    tail = newNode;											
	}
	else{
		curr = head;
		
		//Navigate current pointer to a node before the insertion point
		
		for (int i=1;i<position-1;i++)
		   curr = curr->next;
		   
		//Insert the new element in the list
		newNode->next = curr->next;
		curr->next = newNode;
		
		//Change tail pointer if insert as last node
		if (position == numOfItem+1){
			tail = newNode;
		}
	}
	
	
	numOfItem ++;
	return true;
	
}
	
		
bool LList::deleteNode(int position){
	
	//Validate position
	if (isEmpty() || position > numOfItem || position < 1) {
		if (isEmpty()){
			cout << endl;
			cout << "There's nothing to be removed in your cart." << endl;
		}
	    return false;
	}
		
	//Delete pointer starting from the 1st node
	node *deletePointer = head;
	
	if (position == 1){    //Deleted node is in first position
	
		head = head->next;				
		
		if (numOfItem == 1)	//When only 1 item is on the list		
			tail = NULL;	
	}  
	
	//Deleted node in between the list
	else{
			//Navigate to deleted node and keep track the node before deletion
			node *prevPointer = NULL;
		
			for (int i=1 ;  i< position ; i++){
				prevPointer = deletePointer;
				deletePointer = deletePointer->next;				
			}	
		    
			//Delete the node from the list
			prevPointer->next = deletePointer->next;
		
			//Change tail pointer if it is the last node to be deleted
			if (deletePointer->next == NULL){
				tail = prevPointer;
			}
	}
			
	//Remove the node point by deletePointer
	
	delete deletePointer;
	
	numOfItem--;
	return true;
} 


bool LList::displayAll(){
	int counter = 0;
	
	if (isEmpty()) {
		cout << "There's nothing in your cart yet." << endl << endl;
		cout << endl;
		return false;
	}
	else {

		cout<<setw(37)<<"Your Cart"<<endl;
		cout<<"---------------------------------------------------------------------"<<endl ;
		cout<<"No."<<setw(10)<<"Flavor"<<setw(16)<<"Quantity"<<setw(20)<<"Unit Price(RM)"<<setw(15)<<"Price(RM)"<<endl ;
		cout<<"---------------------------------------------------------------------"<<endl ;
		
		//Customer's order is displayed
		cout<<"_______________________"<<endl ;
		cout<<setw(55)<<"Total Price(RM): "<<getTotal()<<endl;
		cout<<endl<<endl<<endl ; 	
		
		node *curr = head;			
		while (curr != NULL){
			cout << setw(2) << counter+1 << "." << setw(22) << curr -> item.getFlavour() << setw(6) << curr -> item.getWeight () << setw(18) << curr -> item.getPrice ();
			cout << setw(14) << curr -> item.getQty() << setw(19) << (curr -> item.getPrice () * curr -> item.getQty()) << endl;
			curr = curr->next;
			counter++;				
		}
		
		cout << setw(77) << "Total (RM): " << getTotal() << endl << endl;
	}
						
}


bool LList::deleteAll(){
	if (isEmpty()) {
		return false;
	}
	
	node *nextPointer = head->next;
	node *deletePointer = head;
	head = NULL;
	tail = NULL;
	
	while (nextPointer != NULL){
		delete deletePointer;
		deletePointer = nextPointer;
		nextPointer = nextPointer->next;
	}
	
	numOfItem = 0;
	return true;
}


double LList::getTotal (){
	node *curr = head;
	total = 0;
	
	while (curr != NULL){
		total = total + curr->item.getPrice() * curr->item.getQty();
		curr = curr->next;
	}
	return total;
}

