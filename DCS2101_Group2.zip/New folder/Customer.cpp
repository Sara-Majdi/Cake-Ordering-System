#include "Customer.h"
#include "Cake.h"
#include <iostream>
#include <iomanip>
#include "LList.h"
using namespace std; 

//Constructor
Customer::Customer()
{
	customerId;
    name;
	address;
	phoneNum;

}

Customer::Customer(string a, string b, string c, int d)
{
	setCustomerId(a);
	setName(b);
	setAddress(c);
	setPhoneNum(d);

}

//Setters
void Customer::setCustomerId(string a)
{
	customerId = a; 
}

void Customer::setName(string b)
{
	name = b; 
}

void Customer::setAddress(string c)
{
	address = c; 
}

void Customer::setPhoneNum(int d)
{
	phoneNum = d; 
}


//Getters
string Customer::getCustomerId()
{
	return customerId="C22314"; 
}

string Customer::getName()
{
	return name; 
}

string Customer::getAddress()
{
	return address; 
}

int Customer::getPhoneNum()
{
	return phoneNum; 
}

