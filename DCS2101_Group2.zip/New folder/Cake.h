#ifndef CAKE_H
#define CAKE_H

#include <string>

using namespace std;

class Cake{
	
public:
	//Constructor
	Cake();
	Cake(string, int, char, double, double, int, double);
	
	//Setters
	void setOrderId(string);
	void setCakeCode(int);
	void setFlavour(char);
	void setWeight(double);
	void setPrice(double);
	void setQty(int);
	void setAmount(double);
   
	
	//Getters
	string getOrderId();
	int getCakeCode();
	char getFlavour();
	double getWeight();
	double getPrice();
	int getQty();	
	double getAmount();
	
	//Extra functions
	void setOrder (int, char, double, double, int);

	
private:
	//Attributes
	string orderId;       //Cake order ID attribute
	int cakeCode;         //Cake code attribute
	char flavour;       //Cake flavour attribute
	double weight;        //Cake weight attribute
	double price;         //Cake price attribute
	int qty;              //Cake quantity attribute
	double amount;        //Cake amount attribute (unit price * quantity)
	
};
#endif
