#include "Customer.h"
#include "Cake.h"
#include <iostream>
#include <iomanip>
#include "LList.h"
#include <string.h>
using namespace std; 

void cakeMenu(){
	
	// Cake Menu 
	cout<<endl<<setw(45)<<"Welcome to ABC Bakery !!"<<endl ;
	cout<<setw(50)<<"_________________________________________________________________"<<endl ;
	cout<<setw(35)<<"MENU"<<setw(30)<<"|"<<endl<<setw(65)<<"|"<<endl ;
	cout<<setw(14)<<"Code"<<setw(13)<<"Flavor"<<setw(30)<<"Price(1.5KG/2.0KG)"<<setw(8)<<"|"<<endl ;
	cout<<setw(14)<<"----------------------------------------------------------------|"<<endl ;
	cout<<setw(13)<<"C"<<setw(15)<<"Caramel"<<setw(24)<<"RM70/RM120"<<setw(13)<<"|"<<endl ;	
	cout<<setw(13)<<"O"<<setw(12)<<"Oreo"<<setw(27)<<"RM75/RM130"<<setw(13)<<"|"<<endl ;	
	cout<<setw(13)<<"V"<<setw(15)<<"Vanilla"<<setw(24)<<"RM60/RM100"<<setw(13)<<"|"<<endl ;	
	cout<<setw(13)<<"R"<<setw(17)<<"Raspberry"<<setw(22)<<"RM75/RM140"<<setw(13)<<"|"<<endl ;	
	cout<<setw(13)<<"L"<<setw(13)<<"Lemon"<<setw(26)<<"RM60/RM110"<<setw(13)<<"|"<<endl<<setw(65)<<"|"<<endl ;		
	cout<<setw(14)<<"________________________________________________________________|"<<endl ;	

	cout<<endl<<endl<<endl ;
};

void optionMenu(){
	
	//Options Menu 1
	cout<<"________________________________________________________________"<<endl ;
	cout<<endl<<setw(20)<<"No."<<setw(15)<<"Option"<<endl ;
	cout<<"----------------------------------------------------------------"<<endl ;
	cout<<setw(19)<<"1"<<setw(20)<<"Add order "<<endl ;
	cout<<setw(19)<<"2"<<setw(22)<<"Remove order"<<endl ;
	cout<<setw(19)<<"3"<<setw(19)<<"Check out"<<endl ;
	cout<<setw(19)<<"4"<<setw(22)<<"Cancel order"<<endl ;
	cout<<"----------------------------------------------------------------"<<endl ;
	
}

void viewCart(){
	cout<<"_____________________________________________________________________"<<endl<<endl ;
	cout<<setw(37)<<"Your Cart"<<endl;
	cout<<"---------------------------------------------------------------------"<<endl ;
	cout<<"No."<<setw(10)<<"Flavor"<<setw(16)<<"Quantity"<<setw(20)<<"Unit Price(RM)"<<setw(15)<<"Price(RM)"<<endl ;
	cout<<"---------------------------------------------------------------------"<<endl ;
	//cust's order here
	cout<<"_____________________________________________________________________"<<endl ;
	cout<<setw(55)<<"Total Price(RM): "<<endl;
	
	cout<<endl<<endl<<endl; 
}


int main() 
{
	//Declare variables
	
	Cake obj;
	char flavour;
	char weightOption;
	int qty, option1;
	string orderID;
	
	Customer cust;
	string custID;
	string custName;
	string custAddress;
	int custNum;
	
	LList cart;
	bool isValid [5] = {false, false, false, false, false};
	
	//Display Cake Menu
	cakeMenu();

	// Ask user input for cake flavour
	cout<< "Please enter the code of the cake to make an order (C/O/V/R/L) : "; 
	cin>>flavour;
	cout<<endl; 
	obj.setFlavour(flavour);
	
	//Switch case for cake flavour
	switch (flavour)
	{
		case 'C' :
		case 'c' :
			cout<<"You have selected Caramel cake. "<<endl;	
			break;
		
		case 'O' :
		case 'o' : 
			cout<<"You have selected Oreo cake. "<<endl;
			break;
		
		case 'V' :
		case 'v' : 
			cout<<"You have selected Vanilla cake. "<<endl;
			break;
			
		case 'R' :
		case 'r' :
			cout<<"You have selected Raspberry cake. "<<endl;
			break;
			
		case 'L' :
		case 'l' : 
			cout<<"You have selected Lemon cake. "<<endl;
			break;
			
		default : 
		{
			cout<<"Invalid option. Please try again later. "<<endl;
			return 0;
		}
			break;		
	}
	cout<<endl;
	
	// Ask user input for cake weight
	cout<< "Please enter the weight of the cake to proceed with your order [(a)1.5KG (b)2KG] : "; 
	cin>>weightOption;
	cout<<endl; 
	obj.setWeight(weightOption);
	
	switch(weightOption)
	{
		case 'A' :
		case 'a' :
			if(flavour == 'C' ||flavour == 'c' )
			{
				cout<<"You have selected 1.5KG Caramel cake."<<endl;
			}
			else if(flavour == 'O' ||flavour == 'o' )
			{
				cout<<"You have selected 1.5KG Oreo cake."<<endl;
			}
			else if(flavour == 'V' ||flavour == 'v' )
			{
				cout<<"You have selected 1.5KG Vanilla cake."<<endl;
			}
			else if(flavour == 'R' ||flavour == 'r' )
			{
				cout<<"You have selected 1.5KG Raspberry cake."<<endl;
			}
			else if(flavour == 'L' ||flavour == 'l' )
			{
				cout<<"You have selected 1.5KG Lemon cake."<<endl;
			}
			else
			{
			cout<<"Invalid option. Please try again later. "<<endl;
			return 0;
			}
			break;
			
		case 'B' :
		case 'b' :
			if(flavour == 'C' ||flavour == 'c' )
			{
				cout<<"You have selected 2KG Caramel cake."<<endl;
			}
			else if(flavour == 'O' ||flavour == 'o' )
			{
				cout<<"You have selected 2KG Oreo cake."<<endl;
			}
			else if(flavour == 'V' ||flavour == 'v' )
			{
				cout<<"You have selected 2KG Vanilla cake."<<endl;
			}
			else if(flavour == 'R' ||flavour == 'r' )
			{
				cout<<"You have selected 2KG Rasberry cake."<<endl;
			}
			else if(flavour == 'L' ||flavour == 'l' )
			{
				cout<<"You have selected 2KG Lemon cake."<<endl;
			}
			else
			{
			cout<<"Invalid option. Please try again later. "<<endl;
			return 0;
			}
			break;
			
		default : 
		{
			cout<<"Invalid option. Please try again later. "<<endl;
			return 0;
		}
			break;
	}
	cout<<endl;
	
	// Ask user input for cake quantity
	cout<<"How many of these cakes would you add to cart : ";
	cin>>qty;
	cout<<endl;
	if(flavour == 'C' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'C' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'c' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'c' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'C' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'C' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'c' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Caramel cake. Order is added to cart. "<<endl;
	}	
	
	else if(flavour == 'c' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Caramel cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'O' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Oreo cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'O' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Oreo cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'o' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Oreo cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'o' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Oreo cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'O' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Oreo cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'O' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Oreo cake. Order is added to cart. "<<endl;
	}

	else if(flavour == 'o' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Oreo cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'o' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Oreo cake. Order is added to cart. "<<endl;
	}	
	
	else if(flavour == 'V' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Vanilla cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'V' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Vanilla cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'v' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Vanilla cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'v' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Vanilla cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'V' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Vanilla cake. Order is added to cart. "<<endl;
	}
	else if(flavour == 'V' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Vanilla cake. Order is added to cart. "<<endl;
	}
	else if(flavour == 'v' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Vanilla cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'v' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Vanilla cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'R' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Rapsberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'R' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'r' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'r' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'R' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'R' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'r' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'r' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Raspberry cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'L' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Lemon cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'L' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Lemon cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'l' && weightOption == 'A')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Lemon cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'l' && weightOption == 'a')
	{
		cout<<"You have selected "<<qty<<", 1.5KG Lemon cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'L' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Lemon cake. Order is added to cart. "<<endl;
	}
	else if(flavour == 'L' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Lemon cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'l' && weightOption == 'B')
	{
		cout<<"You have selected "<<qty<<", 2KG Lemon cake. Order is added to cart. "<<endl;
	}
	
	else if(flavour == 'l' && weightOption == 'b')
	{
		cout<<"You have selected "<<qty<<", 2KG Lemon cake. Order is added to cart. "<<endl;
	}
	else
	{
	cout<<"Invalid option. Please try again later. "<<endl;
	return 0;
	}

	system("pause");	
	system("cls");

	//Display Options Menu
	optionMenu();
	
	//Ask for user's input
	cout<<"What would you like to do ? (1/2/3/4) "<<endl ;
	cin>>option1;
	cout<<endl;
	
	switch (option1){
		case 1 :
			system("pause");	
			system("cls"); 
			break;
	
		case 2 :
			system("pause");	
			system("cls");
			isValid [0] = false;
			isValid [1] = true;
			break;
			
		case 3 : 
			system("pause");	
			system("cls");
			
			//Ask for customer details
			cout<<"Customer Details"<<endl<<endl;
			cout<<"Name           : ";
			cin>>custName;
			getline(cin,custName);
			cout<<"Address        : ";
			cin>>custAddress;
			getline(cin,custAddress);
			cout<<"Contact Number : +60";
			cin>>custNum;
			cout<<endl;


			cout<<setw(36)<<"Receipt"<<endl;
			cout<<".........................................................................."<<endl ;
			cout<<"Order ID      : "<<obj.getOrderId()<<endl ;  
			cout<<"Name          : "<<custName<<endl ;
			cout<<"Address       : "<<custAddress<<endl ;
			cout<<"Contact Number: +60"<<custNum<<endl ;
			cout<<"Customer ID   : "<<cust.getCustomerId()<<endl ;  
			cout<<".........................................................................."<<endl<<endl ;
			
	
			cout<<setw(37)<<"Your Cart"<<endl;
			cout<<"---------------------------------------------------------------------"<<endl ;
			cout<<"No."<<setw(10)<<"Flavor"<<setw(16)<<"Quantity"<<setw(20)<<"Unit Price(RM)"<<setw(15)<<"Price(RM)"<<endl ;
			cout<<"---------------------------------------------------------------------"<<endl ;
			cart.displayAll();
			//Customer's order is displayed
			cout<<"_____________________________________________________________________"<<endl ;
			cout<<setw(55)<<"Total Price(RM): "<<endl;
			cout<<endl<<endl<<endl ; 


		case 4 :
			cout<<"Your order has been cancelled."<<endl ;
			cout<<"Thank you for your time. Please visit again soon, and have a great day."<<endl;
			break;
			
		default : 
		{
			cout<<"Invalid option. Please try again later. "<<endl;
			return 0;
		}
			break;		
	}
	

	return 0;
}


