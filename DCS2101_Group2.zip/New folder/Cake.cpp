#include "Customer.h"
#include "Cake.h"
#include <iostream>
#include <iomanip>
#include "LList.h"

using namespace std;

//Constructors
Cake::Cake()
{
	orderId;
    cakeCode;
	flavour;
	weight;
	price;
	qty;
	amount;
}

Cake::Cake(string a, int b, char c, double d, double e, int f, double g)
{
	setOrderId(a);
	setCakeCode(b);
	setFlavour(c);
	setWeight(d);
	setPrice(e);
	setQty(f);
	setAmount(g);
}

//Setters
void Cake::setOrderId(string a)
{
	orderId = a; 
}

void Cake::setCakeCode(int b)
{
	cakeCode = b; 
}

void Cake::setFlavour(char c)
{
	flavour = c; 
}

void Cake::setWeight(double d)
{
	weight = d; 
}

void Cake::setPrice(double e)
{
	price = e; 
}

void Cake::setQty(int f)
{
	qty = f; 
}

void Cake::setAmount(double g)
{
	amount = g; 
}

//Getters
string Cake::getOrderId()
{
	return orderId="P2926"; 
}

int Cake::getCakeCode()
{
	return cakeCode; 
}

char Cake::getFlavour()
{
	return flavour; 
}

double Cake::getWeight()
{
	return weight; 
}

double Cake::getPrice()
{
	return price; 
}

int Cake::getQty()
{
	return qty; 
}

double Cake::getAmount()
{
	return amount; 
}

//Extra functions
void Cake::setOrder(int a, char b, double c, double d, int e) {
	cakeCode = a;
	flavour = b;
	weight = c;
	price= d;
	qty = e;
}
